// случайное число в диапазоне
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

// получить из строки положительное число
function getPositiveNumber(inputData) {
    var number = Number(inputData);

    if (!isNaN(number) && number > 0) {
        return number.valueOf();
    } else {
        return null;
    }
}

function write(text, elementId) {
    document.getElementById(elementId).innerHTML = text;
}

function toggle(id) {
    var element = document.getElementById(id);
    element.style.display = element.style.display === 'none' ? '' : 'none';
}

// конфиг игры
var minInt = 0;
var maxInt = 100;
var correctAnswer;
var answerFound = false;

var playersTotal = 2;
var playersLeftGameList = [];
var playersAttempts = [];
var playersLeft;
var currentPlayerNumber;

// установим число попыток для игроков на 0
function initGameState() {
    for (var i = 1; i <= playersTotal; i++) {
        playersAttempts[i] = 0;
    }

    correctAnswer = getRandomInt(minInt, maxInt);
    answerFound = false;
    playersLeftGameList = [];
    playersLeft = playersTotal;
    currentPlayerNumber = 1;
}

function startGame() {
    initGameState();

    toggle('play_rules');
    toggle('play_area');
    toggle('result_area');

    updateGameInfo('Игрок №' + currentPlayerNumber, ++playersAttempts[currentPlayerNumber]);
}

function updateGameInfo(playerName, playerAttempt) {
    write(playerName + ', попытка ' + playerAttempt, 'player_info');
    write('\r\nУгадай целое число от ' + minInt + ' до ' + maxInt, 'game_info');
}

function nextTurn() {
    toggle('guess');
    toggle('nextTurn');

    updateGameInfo('Игрок №' + currentPlayerNumber, ++playersAttempts[currentPlayerNumber]);
}

function guess() {
    toggle('guess');
    toggle('nextTurn');
    if (playersLeft > 0 && !answerFound) {
        var playerName = 'Игрок №' + currentPlayerNumber;
        var userAnswer = document.getElementById('userAnswer').value;
        // пустой ввод, esc или отмена - прервать программу ввода данных
        if (userAnswer === null || userAnswer === '') {
            playersLeft--;
            playersLeftGameList.push(currentPlayerNumber);
            write(playerName + ' покинул игру!', 'game_info');
        } else {
            var numberFromUserAnswer = getPositiveNumber(userAnswer);
            if (numberFromUserAnswer === null) {
                write(playerName + ' ввёл не число, переход хода!', 'game_info');
            } else if (numberFromUserAnswer % 1 !== 0) {
                write(playerName + ' ввёл не целое число, переход хода!', 'game_info');
            } else if (numberFromUserAnswer > correctAnswer) {
                write('Ваш ответ слишком большой', 'game_info');
            } else if (numberFromUserAnswer < correctAnswer) {
                write('Ваш ответ слишком маленький', 'game_info');
            } else if (numberFromUserAnswer === correctAnswer) {
                answerFound = true;
            }
        }

        if (answerFound) {
            endGame();
        }

        // вычисляем номер следующего по очереди не вышедшего игрока
        do {
            if (currentPlayerNumber < playersTotal) {
                currentPlayerNumber++;
            } else {
                currentPlayerNumber = 1;
            }
            if (!playersLeftGameList.includes(currentPlayerNumber)) {
                break;
            }
        } while (playersLeft > 0)
    } else {
        endGame();
    }
}


function endGame() {
    toggle('guess');
    toggle('nextTurn');
    toggle('play_area');
    toggle('play_rules');
    toggle('result_area');

    var message = '';
    if (playersLeft === 0) {
        message += 'Все игроки вышли, игра окончена!';
    }
    message += '<p><b>Итоги игры</b></p>';
    message += '<p>Правильный ответ: <b>' + correctAnswer + '</b></p>';
    message += '<table border="1" cellpadding="1" cellspacing="1">';
    message += '<thead><tr><th>Игрок</th><th>Число попыток</th><th>Статус</th></tr></thead>';
    message += '<tbody>';
    for (var i = 1; i <= playersTotal; i++) {
        message += '<tr>';
        message += '<td>№' + i + '</td>';
        message += '<td>' + playersAttempts[i] + '</td>';
        if (answerFound && i === currentPlayerNumber) {
            message += '<td><b>Победитель!!!</b></td>';
        } else if (playersLeftGameList.includes(i)) {
            message += '<td><i>Покинул игру</i></td>';
        } else {
            message += '<td>Проиграл</td>';
        }
        message += '</tr>';
    }
    message += '</tbody></table>';
    write(message, 'result_area');
}
