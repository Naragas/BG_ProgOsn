<?php
declare(strict_types=1);

$pageData = [
    'page_scripts' => prepareScriptsLinks(['/scripts/guess.js']),
    'page_h1'      => 'Игра угадайка!',
    'page_content' => render('templates/guess.html'),
];

return $pageData;