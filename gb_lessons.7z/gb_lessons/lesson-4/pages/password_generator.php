<?php
declare(strict_types=1);

session_start();

function generatePassword(int $length): string
{
    $password = '';
    $charset  = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

    for ($i = 0; $i < $length; $i++) {
        $random_int = mt_rand();
        $password   .= $charset[$random_int % strlen($charset)];
    }

    return $password;
}

if (isset($_POST['password_length'])) {
    $passwordLength              = (int)$_POST['password_length'];
    $_SESSION['password_length'] = $passwordLength > 0 ? $passwordLength : 10;

    header('Location: /password-generator');

    exit();
}

$length = null;
if (isset($_SESSION['password_length'])) {
    $length = (int)$_SESSION['password_length'];
    unset($_SESSION['password_length']);
}

$pageData = [
    'page_h1'      => 'Генерация паролей',
    'page_content' => render('templates/password_generator.html'),
    'password'     => $length ? 'Ваш пароль: '.generatePassword($length) : '',
];

return $pageData;