<?php
declare(strict_types=1);

$pageData = [
    'user_name'      => 'Сергей Иванов',
    'user_seniority' => (int)date('Y') - 2011,
    'game_links'     => '',
    'page_h1'      => 'Личный сайт',
    'page_content' => render('templates/index.html'),
];

foreach ($gameList as $item) {
    $pageData['game_links'] .= prepareLink($item['link'], $item['title']);
}

return $pageData;
