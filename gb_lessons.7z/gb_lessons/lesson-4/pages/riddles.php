<?php
declare(strict_types=1);

session_start();
if (isset($_POST['userAnswer'])) {
    $_SESSION['userAnswer'] = (array)$_POST['userAnswer'];

    header('Location: /riddles');

    exit();
}

$userAnswers = null;
if (isset($_SESSION['userAnswer'])) {
    $userAnswers = (array)$_SESSION['userAnswer'];
    unset($_SESSION['userAnswer']);
}

$riddles      = [
    [
        'Не кузнец, не плотник, а первый на селе работник.',
        ['конь', 'лошадь', 'лошадка'],
        '1',
    ],
    [
        'Не книжка, а с листьями.',
        ['капуста'],
        '2',
    ],
    [
        'Кто на ветке шишки грыз и бросал объедки вниз?',
        ['белка', 'белочка', 'бельчонок'],
        '3',
    ],
    [
        'Не птичка, а с крыльями: над цветами летает, нектар собирает.',
        ['бабочка', 'пчела', 'пчёлка', 'пчелка'],
        '4',
    ],
];
$rightAnswers = 0;
$riddlesList  = '';
foreach ($riddles as $item) {
    if ($userAnswers !== null) {
        $value = $userAnswers[$item[2]] ?: '';
        if (in_array(mb_strtolower($value), $item[1], true)) {
            $class = 'valid';
            ++$rightAnswers;
        } else {
            $class = 'invalid';
        }
    } else {
        $value = '';
        $class = '';
    }
    $riddlesList .= sprintf(
        '<p>%s</p><input type="text" name="userAnswer[%s]" class="%s" value="%s">',
        $item[0],
        $item[2],
        $class,
        $value
    );
}

$pageData = [
    'page_scripts' => '',
    'page_h1'      => 'Отгадай загадки!',
    'page_content' => render(
        'templates/riddles.html',
        [
            'riddles_list' => $riddlesList,
            'riddles_info' => $userAnswers !== null ? 'Правильных ответов: '.$rightAnswers : '',
        ]
    ),
];

return $pageData;