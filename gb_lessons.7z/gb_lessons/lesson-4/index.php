<?php
declare(strict_types=1);

require_once 'functions/template_functions.php';

function setMenuItemActive(array &$pageMenu, string $activeElement): void
{
    foreach ($pageMenu as &$item) {
        if ($item['link'] === $activeElement) {
            $item['active'] = true;
        } else {
            $item['active'] = false;
        }
    }
}

$gameList = [
    ['link' => '/riddles', 'title' => 'Загадки', 'active' => false],
    ['link' => '/guess', 'title' => 'Уагадайка', 'active' => false],
    ['link' => '/password-generator', 'title' => 'Генератор пароля', 'active' => false],
];
$pageMenu = [
    ['link' => '/', 'title' => 'Главная', 'active' => true],
];
$pageMenu = array_merge($pageMenu, $gameList);
$pageData = [
    'meta_title'   => 'Личный сайт студента GeekBrains',
    'page_styles'  => '',
    'page_scripts' => '',
    'page_h1'      => '',
    'page_content' => '',
    'page_footer'  => render('templates/footer.html', ['year' => date('Y')]),
];

$routeMap   = [
    '/'                   => ['controller' => 'index'],
    '/riddles'            => ['controller' => 'riddles'],
    '/guess'              => ['controller' => 'guess'],
    '/password-generator' => ['controller' => 'password_generator'],
];
$pathInfo   = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$routeFound = isset($routeMap[$pathInfo]);

$renderedData = '';
if ($routeFound) {
    setMenuItemActive($pageMenu, $pathInfo);
    $pageData              = array_merge($pageData, include 'pages/'.$routeMap[$pathInfo]['controller'].'.php');
    $pageData['page_menu'] = prepareMenuLinks($pageMenu);

    $renderedData = render('templates/base.html', $pageData);
}
if ($renderedData === '') {
    $renderedData = render('templates/error404.html', $pageData);
}

header('Content-Type: text/html');
echo $renderedData;