<?php
declare(strict_types=1);

function render(string $template, array $data = []): string
{
    if (!file_exists($template)) {
        return '';
    }

    return str_replace(
        array_map(
            function ($value) {
                return '{{'.$value.'}}';
            },
            array_keys($data)
        ),
        array_values($data),
        file_get_contents($template)
    );
}

function prepareMenuLinks(array $links): string
{
    $result = '';
    foreach ($links as ['link' => $link, 'active' => $active, 'title' => $title]) {
        $result .= sprintf(
            '<li>%s</li>',
            prepareLink(
                $link,
                $title,
                ($active ? 'active' : 'not-active')
            )
        );
    }

    return $result === '' ? '' : '<ul>'.$result.'</ul>';
}

function prepareLink(string $address, string $title, string $class = ''): string
{
    return sprintf(
        '<a href="%s" class="%s">%s</a>',
        $address,
        $class,
        $title
    );
}

function prepareScriptsLinks(array $links): string
{
    $result = '';
    foreach ($links as $link) {
        $result .= sprintf('<script type="text/javascript" src="%s"></script>', $link);
    }

    return $result;
}

function prepareStyles(array $links): string
{
    $result = '';
    foreach ($links as $link) {
        $result .= sprintf('<link rel="stylesheet" href="%s">', $link);
    }

    return $result;
}
