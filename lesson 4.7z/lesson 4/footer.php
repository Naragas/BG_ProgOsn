<div class="footer">
	Copyright &copy; <?php echo date("Y");?> Ivan Sakharov
<div>